var imgArr = [
			{name:"back",path:"./resource/imgs/bg_medgame.jpg"},
			{name:"player",path:"./resource/imgs/cup.png"},
			{name:"medicine0",path:"./resource/imgs/medicine0.png"},
			{name:"medicine1",path:"./resource/imgs/medicine1.png"},
			{name:"medicine2",path:"./resource/imgs/medicine2.png"},
			{name:"medicine3",path:"./resource/imgs/medicine3.png"},
			{name:"medicine4",path:"./resource/imgs/medicine4.png"},
			{name:"medicine5",path:"./resource/imgs/medicine5.png"},
			{name:"medicine6",path:"./resource/imgs/medicine6.png"}
		];