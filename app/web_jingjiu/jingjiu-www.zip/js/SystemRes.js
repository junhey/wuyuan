
var client_width;
var client_height;
this.systemInit = function(){
	client_width = document.body.clientWidth;
	client_height = document.body.clientHeight;
}
